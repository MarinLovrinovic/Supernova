public enum GameScene {
    TitleScreen,
    WaitingRoom,
    Battle
}

// 203f6949-8ca3-4ba7-b0d1-5e43b67c56e2
// com.unity.nuget.mono-cecil@1.10.2