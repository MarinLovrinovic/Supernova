public enum BodyType
{
    Basic,
    Heavy,
    Light
}
