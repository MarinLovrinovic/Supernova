using System.Diagnostics.Tracing;


public enum Upgrades
{
    Shield,
    Rockets,
    Spaceship,
    Sword
    
}
