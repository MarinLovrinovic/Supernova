public enum WeaponType
{
    None,
    Standard
}
