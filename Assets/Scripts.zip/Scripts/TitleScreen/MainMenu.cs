using UnityEngine;


public class MainMenu : MonoBehaviour
{
    public void PlayGame()
    {
    }

    public void OptionsMenu()
    {
    }
    public void QuitGame()
    {
        Application.Quit();
    }
}
