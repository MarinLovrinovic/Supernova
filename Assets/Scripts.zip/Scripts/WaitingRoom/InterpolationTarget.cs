using UnityEngine;


public class InterpolationTarget : MonoBehaviour
{
    public Transform Target;
}
